from django.db.models import Count, F, Sum
from django.shortcuts import get_object_or_404
from rest_framework import viewsets
from rest_framework.response import Response

from .models import (
    Categories,
    Donation,
    Donors,
    GoodsReceipt,
    ItemStatus,
    Items,
    Locations,
    PurchaseOrder,
    Shed,
    StorageLocation,
    StorageShed,
    StorageType,
    Stock,
    StockTransaction,
    Suppliers,
    Units,
)
from .serializers import (
    CategoriesSerializer,
    DonationSerializer,
    DonorsSerializer,
    GoodsReceiptSerializer,
    ItemStatusSerializer,
    ItemsSerializer,
    LocationsSerializer,
    PurchaseOrderSerializer,
    ShedSerializer,
    StorageTypeSerializer,
    StorageLocationSerializer,
    StorageShedSerializer,
    StockSerializer,
    StockTransactionSerializer,
    SuppliersSerializer,
    TotalInventorySerializer,
    UnitsSerializer,
)


class CategoriesViewSet(viewsets.ModelViewSet):
    queryset = Categories.objects.all()
    serializer_class = CategoriesSerializer


class DonorsViewSet(viewsets.ModelViewSet):
    queryset = Donors.objects.all()
    serializer_class = DonorsSerializer


class DonationViewSet(viewsets.ModelViewSet):
    queryset = Donation.objects.select_related('donor', 'warehouse', 'item')
    serializer_class = DonationSerializer


class GoodsReceiptViewSet(viewsets.ModelViewSet):
    queryset = GoodsReceipt.objects.select_related('po__supplier', 'item')
    serializer_class = GoodsReceiptSerializer


class PurchaseOrderViewSet(viewsets.ModelViewSet):
    queryset = PurchaseOrder.objects.select_related('location', 'supplier', 'item')
    serializer_class = PurchaseOrderSerializer


class SuppliersViewSet(viewsets.ModelViewSet):
    queryset = Suppliers.objects.all()
    serializer_class = SuppliersSerializer


class UnitsViewSet(viewsets.ModelViewSet):
    queryset = Units.objects.all()
    serializer_class = UnitsSerializer


class ItemStatusViewSet(viewsets.ModelViewSet):
    queryset = ItemStatus.objects.all()
    serializer_class = ItemStatusSerializer


class ItemsViewSet(viewsets.ModelViewSet):
    """GET /api/items/?item_category=<id> filters by category; POST accepts the same param to set it."""
    queryset = Items.objects.select_related('item_category')
    serializer_class = ItemsSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        category_id = self.request.query_params.get('item_category')
        if category_id:
            queryset = queryset.filter(item_category=category_id)
        return queryset

    def perform_create(self, serializer):
        category_id = self.request.query_params.get('item_category')
        if category_id:
            serializer.save(item_category=get_object_or_404(Categories, pk=category_id))
        else:
            serializer.save()


class LocationsViewSet(viewsets.ModelViewSet):
    queryset = Locations.objects.all()
    serializer_class = LocationsSerializer


class ShedViewSet(viewsets.ModelViewSet):
    queryset = Shed.objects.all()
    serializer_class = ShedSerializer


class StorageTypeViewSet(viewsets.ModelViewSet):
    queryset = StorageType.objects.all()
    serializer_class = StorageTypeSerializer


class StorageLocationViewSet(viewsets.ModelViewSet):
    queryset = StorageLocation.objects.select_related('location', 'type')
    serializer_class = StorageLocationSerializer


class StorageShedViewSet(viewsets.ModelViewSet):
    queryset = StorageShed.objects.select_related('sto_loc__location', 'shed')
    serializer_class = StorageShedSerializer


class StockViewSet(viewsets.ModelViewSet):
    queryset = Stock.objects.select_related(
        'item', 'status', 'location__shed', 'location__sto_loc__location'
    )
    serializer_class = StockSerializer


class StockTransactionViewSet(viewsets.ModelViewSet):
    queryset = StockTransaction.objects.all()
    serializer_class = StockTransactionSerializer


class TotalInventoryViewSet(viewsets.ViewSet):
    """
    Read-only total stock per item.
    GET /api/total-inventory/
    """
    def list(self, request):
        inventory = (
            Stock.objects
            .values(
                'item_id', 'unit',
                item_name=F('item__item_name'),
                item_code=F('item__item_code'),
                category_name=F('item__item_category__category_name'),
            )
            .annotate(total_quantity=Sum('quantity'), stock_entries=Count('stock_id'))
            .order_by('-total_quantity')
        )
        return Response(TotalInventorySerializer(inventory, many=True).data)
